/** Commons and park ground: quiet ground beneath planting, with a soft earth edge. */
export const greenPalettes = {
  temperate: {turf:'#a8bc83',light:'#c4d09e',edge:'#81906b'},
  desert: {turf:'#cbbb94',light:'#e1d1ae',edge:'#a59577'},
  tundra: {turf:'#bdc6bc',light:'#e4e9e2',edge:'#949f97'},
  tropical: {turf:'#88ae79',light:'#b2c894',edge:'#698b65'},
  coastal: {turf:'#b8c4a0',light:'#d4dcc0',edge:'#909e86'},
};
export function greenGround(d, biome='temperate', {unit=1,bounds=[0,0,64,64],id='green',seed=0}={}) {
  const b=greenPalettes[biome]?biome:'temperate',p=greenPalettes[b];
  const t=k=>`var(--sm-green-${b}-${k}, ${p[k]})`;
  const n=v=>Number(v.toFixed(3));
  // Plants belong to the vegetation layer. Repeated curved ground strokes
  // read as little hills and distract from the paths and shaded groves.
  return `<g data-green-biome="${b}"><path d="${d}" fill="${t('turf')}" stroke="${t('edge')}" stroke-width="${n(.45*unit)}" stroke-linejoin="round"/></g>`;
}
