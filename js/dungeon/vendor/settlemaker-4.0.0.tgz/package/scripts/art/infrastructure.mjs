/** Pure SVG authoring: path-following walls, span-aware bridges and seeded henges.
 * No filesystem or DOM dependency; used by the build script and live gallery.
 */
export const palettes={
  temperate:{stone:'#aaa99d',light:'#d2d1c1',dark:'#828784',wood:'#a38b6c',woodLight:'#cfb994',roof:'#88929e',ground:'#a3c98d',water:'#a6c8cf'},
  desert:{stone:'#c3b194',light:'#e8d9ba',dark:'#a59680',wood:'#b69a72',woodLight:'#d9c39b',roof:'#c4ac89',ground:'#d9c48f',water:'#9dbfc4'},
  tundra:{stone:'#909b9f',light:'#bcc7c9',dark:'#697780',wood:'#90867a',woodLight:'#b9b1a4',roof:'#7f8b98',ground:'#e6ecef',water:'#9ab7c7'},
  tropical:{stone:'#92988c',light:'#bfc5b2',dark:'#687c70',wood:'#a18e68',woodLight:'#c9ba91',roof:'#af9c78',ground:'#6d9e5c',water:'#83b8b2'},
  coastal:{stone:'#99a8a3',light:'#c8d3c9',dark:'#758a89',wood:'#9b9381',woodLight:'#c4bcaa',roof:'#869e99',ground:'#cfd6b0',water:'#9fc6ce'},
};
const ink='var(--sm-ink, #33262e)',snow='var(--sm-snow, #f2f6f8)';
export const number=n=>Number(n.toFixed(3));
const token=(b,k)=>`var(--sm-infra-${b}-${k}, ${palettes[b][k]})`;
const points=p=>p.map(([x,y],i)=>`${i?'L':'M'}${number(x)},${number(y)}`).join(' ');
const path=(d,fill='none',sw=.6,stroke=ink,extra='')=>`<path d="${d}" fill="${fill}" stroke="${stroke}" stroke-width="${sw}" ${extra}/>`;
const rect=(x,y,w,h)=>`M${number(x)},${number(y)}h${number(w)}v${number(h)}h${number(-w)}Z`;
const wrap=body=>`<g stroke-linejoin="round" stroke-linecap="round">${body}</g>`;
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
function pen(){
  let body='',sil='';
  return {
    shape(d,fill,sw=1.8){body+=path(d,fill,sw);sil+=path(d,'currentColor',sw,'currentColor');},
    detail(d,fill='none',sw=.6,extra=''){body+=path(d,fill,sw,ink,extra);},
    circle(x,y,r,fill,sw=.8,casts=false){const d=`M${number(x-r)},${number(y)}a${r},${r} 0 1 0 ${2*r},0a${r},${r} 0 1 0 ${-2*r},0Z`;if(casts)this.shape(d,fill,sw);else this.detail(d,fill,sw);},
    raw(s){body+=s;},
    result(){return {body:wrap(body),sil:wrap(sil)};},
  };
}
function metrics(input){
  const p=input.filter((v,i)=>i===0||Math.hypot(v[0]-input[i-1][0],v[1]-input[i-1][1])>1e-6);
  if(p.length<2)throw new Error('A wall needs at least two distinct points.');
  const cumulative=[0];for(let i=1;i<p.length;i++)cumulative.push(cumulative[i-1]+Math.hypot(p[i][0]-p[i-1][0],p[i][1]-p[i-1][1]));
  const length=cumulative.at(-1);
  function at(d){
    d=clamp(d,0,length);let i=1;while(i<p.length-1&&cumulative[i]<d)i++;
    const a=p[i-1],b=p[i],span=cumulative[i]-cumulative[i-1],t=(d-cumulative[i-1])/span;
    return {p:[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t],t:[(b[0]-a[0])/span,(b[1]-a[1])/span]};
  }
  function slice(a,b){return [at(a).p,...p.filter((_,i)=>cumulative[i]>a+1e-5&&cumulative[i]<b-1e-5),at(b).p];}
  const corners=[];
  for(let i=1;i<p.length-1;i++){
    const a=at(cumulative[i]-.01).t,b=at(cumulative[i]+.01).t;
    if(a[0]*b[0]+a[1]*b[1]<.9)corners.push(cumulative[i]);
  }
  return {p,length,cumulative,at,slice,corners};
}
function oriented(center,tangent,along,across){const [x,y]=center,[tx,ty]=tangent;return [x+tx*along-ty*across,y+ty*along+tx*across];}

export const wallKinds=['curtain','rubble','palisade'];
/** Width stays constant around bends. Gates remove intervals from BOTH layers. */
export function wall(input,{biome='temperate',kind='curtain',width=12,gates=[],detailPitch=8,detailBounds=[-Infinity,-Infinity,Infinity,Infinity]}={}){
  if(!palettes[biome]||!wallKinds.includes(kind)||!Number.isFinite(width)||width<4||!Number.isFinite(detailPitch)||detailPitch<2)throw new Error('Invalid wall profile.');
  if(!Array.isArray(input)||input.some(p=>!Array.isArray(p)||p.length!==2||!p.every(Number.isFinite)))throw new Error('Invalid wall points.');
  if(gates.some(g=>!Number.isFinite(g.at)||!Number.isFinite(g.width)||g.width<=0))throw new Error('Invalid wall gate.');
  const m=metrics(input),half=width/2,p=pen();
  const blocked=gates.map(g=>[clamp(g.at-g.width/2,0,m.length),clamp(g.at+g.width/2,0,m.length)]).sort((a,b)=>a[0]-b[0]);
  const intervals=[];let start=0;
  for(const[a,b]of blocked){if(a>start)intervals.push([start,a]);start=Math.max(start,b);}if(start<m.length)intervals.push([start,m.length]);
  const closed=Math.hypot(input[0][0]-input.at(-1)[0],input[0][1]-input.at(-1)[1])<1e-6;
  if(closed&&intervals.length>1&&intervals[0][0]===0&&intervals.at(-1)[1]===m.length){
    const first=intervals.shift(),last=intervals.pop();intervals.push([last[0],m.length+first[1]]);
  }
  const section=(a,b)=>points(b>m.length?[...m.slice(a,m.length),...m.slice(0,b-m.length).slice(1)]:m.slice(a,b))+(closed&&!blocked.length?'Z':'');
  const nearGate=d=>blocked.some(([a,b])=>d>a-half&&d<b+half);
  for(const[a,b]of intervals){
    if(b-a<.01)continue;
    const d=section(a,b);
    // The silhouette is the same stroked path. Butt caps keep the gate opening
    // exact; round joins prevent miter spikes at acute boundary corners.
    p.raw(path(d,'none',width,ink,'stroke-linecap="butt"'));
    p.raw(path(d,'none',width-2,token(biome,kind==='palisade'?'wood':'stone'),'stroke-linecap="butt"'));
    p.raw(path(d,'none',kind==='curtain'?width*.34:width*.5,token(biome,kind==='palisade'?'woodLight':'light'),'stroke-linecap="butt"'));
  }
  for(let d=detailPitch/2;d<m.length;d+=kind==='palisade'?3.8:detailPitch){
    if(d<half||d>m.length-half||nearGate(d)||m.corners.some(c=>Math.abs(c-d)<half))continue;
    const sample=m.at(d);
    // Keep the original distance phase, gate exclusions and complete base
    // paths. Only omit motifs whose entire stroke envelope is offscreen.
    // Every profile fits within half+4 of its sample, including its pen.
    const reach=half+4;
    if(detailBounds&&(sample.p[0]+reach<detailBounds[0]||sample.p[1]+reach<detailBounds[1]
      ||sample.p[0]-reach>detailBounds[2]||sample.p[1]-reach>detailBounds[3]))continue;
    const loc=(u,v)=>oriented(sample.p,sample.t,u,v);
    if(kind==='palisade'){
      p.detail(points([loc(0,-half+1.2),loc(.15,half-1.2)]),'none',.65);
      p.detail(points([loc(-.8,-half+1.3),loc(.8,-half+1.3)]),'none',.7);
    }else if(kind==='curtain'){
      for(const sign of [-1,1])p.detail(points([loc(-1.8,sign*(half-1.3)),loc(1.8,sign*(half-1.3)),loc(1.8,sign*(half-3.4)),loc(-1.8,sign*(half-3.4))])+'Z',token(biome,'light'),.55);
      p.detail(points([loc(0,-width*.16),loc(0,width*.16)]),'none',.45);
    }else{
      p.detail(points([loc(-2.4,-half+2),loc(.2,-half+1.7),loc(2.5,.3),loc(-.7,half-1.7),loc(-2.8,.3)])+'Z',token(biome,'light'),.45);
    }
    if(biome==='tundra')p.detail(points([loc(-1.6,-half+1.2),loc(1.6,-half+1.2),loc(1.1,-half+2.5),loc(-1.8,-half+2.2)])+'Z',snow,0);
  }
  const result=p.result();
  result.sil=wrap(intervals.map(([a,b])=>[width,width-2,kind==='curtain'?width*.34:width*.5]
    .map(w=>path(section(a,b),'none',w,'currentColor','stroke-linecap="butt"')).join('')).join(''));
  const xs=input.map(p=>p[0]),ys=input.map(p=>p[1]),x0=Math.min(...xs)-half-4,y0=Math.min(...ys)-half-4,
    x1=Math.max(...xs)+half+4,y1=Math.max(...ys)+half+4;
  return {...result,viewBox:[x0,y0,x1-x0,y1-y0],anchor:[(x0+x1)/2,(y0+y1)/2],category:'wall',biome,kind,
    centreline:input,width,length:m.length,gaps:blocked,gateAnchors:gates.map(g=>({at:m.at(g.at).p,tangent:m.at(g.at).t,width:g.width})),
    notes:'Place along the actual boundary; no cardinal snapping. Width and detail spacing are independent of path length.'};
}

export const bridgeKinds=['stone-footbridge','stone-roadbridge','stone-multispan','timber-footbridge','timber-trestle','covered-bridge'];
/** Rebuild masonry/planks/piers at their own pitch when length changes. */
export function bridge(kind,{biome='temperate',length=64,width}={}){
  if(!bridgeKinds.includes(kind)||!palettes[biome]||!Number.isFinite(length)||length<28||length>256)throw new Error('Invalid bridge span.');
  const timber=kind.startsWith('timber')||kind==='covered-bridge',foot=kind.endsWith('footbridge');
  width??=foot?10:18;
  if(!Number.isFinite(width)||width<8||width>36)throw new Error('Invalid bridge width.');
  const p=pen(),x0=16,x1=x0+length,cy=32,y0=cy-width/2,y1=cy+width/2;
  const material=token(biome,timber?'wood':'stone'),light=token(biome,timber?'woodLight':'light');
  const piers=kind==='stone-multispan'||kind==='timber-trestle'?Math.max(1,Math.floor(length/24)):0;
  // Cutwaters and trestle caps are visible beside the deck in plan view;
  // the underside arch is not falsely drawn across the roadway.
  const pierPositions=[];
  for(let i=1;i<=piers;i++){
    const x=x0+length*i/(piers+1);pierPositions.push(x);
    const d=timber?rect(x-2.6,y0-5,5.2,width+10):points([[x-3.4,y0-1],[x,y0-6],[x+3.4,y0-1],[x+3.4,y1+1],[x,y1+6],[x-3.4,y1+1]])+'Z';
    p.shape(d,material,1.3);
  }
  // Bank seats flare outside the bridge deck, leaving the travel axis open.
  for(const x of [x0,x1-5])p.shape(rect(x,y0-4,5,width+8),material,1.5);
  const outline=points([[x0,y0-1],[x0+6,y0],[x1-6,y0],[x1,y0-1],[x1,y1+1],[x1-6,y1],[x0+6,y1],[x0,y1+1]])+'Z';
  p.shape(outline,light,1.8);
  const pitch=timber?3.4:7;
  for(let x=x0+2;x<x1-1;x+=pitch){
    p.detail(points([[x,y0+1.1],[x+.18*Math.sin(x),y1-1.1]]),'none',timber?.5:.4);
    if(!timber)p.detail(`M${number(x)},${cy}h${number(Math.min(pitch,x1-x))}`,'none',.35);
    else if(x+pitch<x1-2)p.detail(`M${number(x+1)},${number(y0+2.5)}l.6,.1M${number(x+1)},${number(y1-2.5)}l.6,.1`,'none',.5);
  }
  for(const y of [y0+.8,y1-.8]){
    p.detail(`M${x0+1},${number(y)}H${x1-1}`,'none',timber?1.3:2.4,`stroke-linecap="butt"`);
    if(!timber)p.raw(path(`M${x0+1},${number(y)}H${x1-1}`,'none',1,material,'stroke-linecap="butt"'));
  }
  // Small joints / timber railing posts remain within the bridge footprint.
  for(let x=x0+3;x<x1-2;x+=8)for(const y of [y0+1.2,y1-1.2])p.detail(rect(x-.7,y-.65,1.4,1.3),material,.4);
  if(kind==='covered-bridge'){
    const rx=x0+5,rw=length-10,ry=y0-2,rh=width+4;
    p.shape(rect(rx,ry,rw,rh),token(biome,'roof'),1.7);
    p.detail(points([[rx+1,ry+1],[rx+rw-1,ry+1],[rx+rw-4,cy],[rx+4,cy]])+'Z',light,0);
    for(let x=rx+3;x<rx+rw-2;x+=3.1)p.detail(`M${number(x)},${number(ry+2)}V${cy-1}M${number(x+.12)},${cy+1}V${number(ry+rh-2)}`,'none',.5);
    if(biome==='tundra')p.detail(points([[rx+1,ry+1],[rx+rw-1,ry+1],[rx+rw-4,cy],[rx+4,cy]])+'Z',snow,0);
    p.detail(`M${rx+4},${cy}H${rx+rw-4}`,'none',1.1);
    for(const x of [rx,rx+rw-2])for(const y of [y0-3,y1+1])p.shape(rect(x,y,2,2),material,.8);
  }
  if(biome==='tundra'){
    for(const x of [x0+.8,x1-4.2])for(const y of [y0-3.2,y1+1.5])p.detail(rect(x,y,3.4,1.5),snow,0);
    // The travelled deck remains readable; remnants sit by parapets/bank seats.
    if(kind!=='covered-bridge')p.detail(points([[x0+7,y0+2],[x1-7,y0+2],[x1-10,y0+3.3],[x0+13,y0+3.6]])+'Z',snow,0);
  }
  return {...p.result(),viewBox:[0,0,length+32,64],anchor:[16+length/2,32],category:'bridge',biome,kind,
    deckBounds:[x0,y0,x1,y1],bankAnchors:[[x0,cy],[x1,cy]],travelAxis:[1,0],clearTravelWidth:width-4,
    crossingLength:length,pierPositions,piersInWater:piers>0,
    clearanceMode:kind==='covered-bridge'?'covered passage below roof':'open deck',
    notes:'Fit bank seats to land; validate pier sites and water clearance in the planner. Rebuild for a new span, do not stretch a glyph.'};
}

function random(seed){let s=seed>>>0;return()=>{s+=0x6D2B79F5;let t=Math.imul(s^(s>>>15),1|s);t^=t+Math.imul(t^(t>>>7),61|t);return((t^(t>>>14))>>>0)/4294967296;};}
export const hengeKinds=['lintelled-ring','broken-ring','double-ring','horseshoe','oval-ring','ruined-ring'];
export function henge(kind,{biome='temperate',seed=1}={}){
  if(!hengeKinds.includes(kind)||!palettes[biome]||!Number.isInteger(seed)||seed<0||seed>0xffffffff)throw new Error('Invalid henge recipe.');
  const rng=random(seed),p=pen(),cx=48,cy=46,stones=[],lintels=[],fallen=[];
  function stone(x,y,w,h,angle,lying=false){
    const t=[Math.cos(angle),Math.sin(angle)],loc=(u,v)=>oriented([x,y],t,u,v);
    const vertices=[[-w/2+.4,-h/2], [w/2-.5,-h/2+.15], [w/2,h/2-.7], [w/2-.9,h/2],[-w/2+.2,h/2-.2],[-w/2,-h/2+.8]].map(([u,v])=>loc(u+(rng()-.5)*.35,v+(rng()-.5)*.3));
    p.shape(points(vertices)+'Z',token(biome,'dark'),lying?1.1:1.45);
    const top=[[-w*.36,-h*.35],[w*.33,-h*.34],[w*.32,h*.12],[-w*.34,h*.23]].map(([u,v])=>loc(u,v));
    p.detail(points(top)+'Z',biome==='tundra'&&!lying?snow:token(biome,'light'),0);
    if(w>4.5)p.detail(points([loc(-w*.12,-h*.24),loc(w*.04,-h*.04),loc(-w*.06,h*.2)]),'none',.42,'opacity=".65"');
    stones.push({at:[number(x),number(y)],size:[number(w),number(h)],rotation:number(angle*180/Math.PI),state:lying?'fallen':'standing'});
  }
  function lintel(a,b){
    const dx=b[0]-a[0],dy=b[1]-a[1],len=Math.hypot(dx,dy),t=[dx/len,dy/len],c=[(a[0]+b[0])/2,(a[1]+b[1])/2];
    const pts=[[-len/2-.8,-1.7],[len/2+.6,-1.5],[len/2+.8,1.6],[-len/2-.6,1.9]].map(([u,v])=>oriented(c,t,u,v));
    p.shape(points(pts)+'Z',token(biome,'stone'),1.15);
    p.detail(points([[-len/2+.1,-.8],[len/2-.2,-.7],[len/2-.3,.25],[-len/2+.2,.5]].map(([u,v])=>oriented(c,t,u,v)))+'Z',biome==='tundra'?snow:token(biome,'light'),0);
    lintels.push({from:a.map(number),to:b.map(number)});
  }
  function ring(radius,count,{oval=false,broken=false,beams=false}={}){
    const positions=[];
    for(let i=0;i<count;i++){
      const theta=-Math.PI/2+i*2*Math.PI/count+(rng()-.5)*.14;
      const rr=radius+(rng()-.5)*3.5,x=cx+Math.cos(theta)*rr*(oval?1.12:1),y=cy+Math.sin(theta)*rr*(oval?.85:1);
      // A consistent southern entrance across every ring; no debris in it.
      if(y>cy&&Math.abs(x-cx)<9){positions.push(null);continue;}
      if(broken&&i%5===seed%5){positions.push(null);fallen.push([x+Math.cos(theta)*3,y+Math.sin(theta)*3,theta]);continue;}
      const w=4.5+rng()*2.7,h=5.6+rng()*2.8;stone(x,y,w,h,theta+Math.PI/2+(rng()-.5)*.3);
      positions.push([x,y]);
    }
    if(beams)for(let i=0;i<count;i+=2){const a=positions[i],b=positions[(i+1)%count];if(a&&b)lintel(a,b);}
  }
  if(kind==='horseshoe'){
    const count=5+seed%2;
    for(let i=0;i<count;i++){
      const theta=2.22+i*4.98/(count-1)+(rng()-.5)*.08,r=24+(rng()-.5)*3,c=[cx+Math.cos(theta)*r,cy+Math.sin(theta)*r],t=[-Math.sin(theta),Math.cos(theta)];
      const a=oriented(c,t,-4,0),b=oriented(c,t,4,0);
      stone(...a,4.6+rng(),6.5+rng(),theta);stone(...b,4.6+rng(),6.5+rng(),theta);lintel(a,b);
    }
  }else{
    const broken=kind==='broken-ring'||kind==='ruined-ring';
    ring(kind==='oval-ring'?30:31,12+2*(seed%2),{oval:kind==='oval-ring',broken,beams:kind==='lintelled-ring'||kind==='broken-ring'});
    if(kind==='double-ring')ring(19,8+seed%2);
    if(kind==='ruined-ring')fallen.push([29,36,.8],[64,31,-.4]);
  }
  for(const[x,y,a]of fallen){
    // Fell inward if necessary to keep the 96-unit asset envelope clear.
    const X=clamp(x,13,83),Y=clamp(y,12,79);
    if(Y>cy&&Math.abs(X-cx)<11)continue;
    stone(X,Y,7.5+rng()*2,3+rng()*.8,a+(rng()-.5)*.5,true);
    if(kind==='ruined-ring')stone(X-3,Y+3.5,2.4+rng(),2.1+rng()*.5,a+.8,true);
  }
  return {...p.result(),viewBox:[0,0,96,96],anchor:[48,48],category:'henge',biome,kind,seed,
    stones,lintels,entrance:[48,88],frontVector:[0,1],clearCentre:[48,46,9],accessPolyline:[[48,90],[48,57],[48,46]],
    rotation:'free',ground:'transparent',
    notes:'Stone monument only. Optional earthwork bank/ditch belongs on a separate ground layer. Seed changes stone size, spacing, lean, chips and collapse without blocking the entrance.'};
}

export function svg(asset,{shadow=true,title=''}={}){
  const vb=asset.viewBox;
  const safeTitle=String(title).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${vb.join(' ')}" width="${vb[2]*2}" height="${vb[3]*2}">${title?`<title>${safeTitle}</title>`:''}${shadow?`<g transform="translate(2.6,3.6)" opacity=".2" color="#46303c">${asset.sil}</g>`:''}${asset.body}</svg>`;
}
